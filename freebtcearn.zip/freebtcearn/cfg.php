<?

$cookie="xxxxx";